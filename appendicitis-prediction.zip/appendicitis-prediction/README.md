# Predicting Paediatric Appendicitis with Machine Learning

Can lab results, clinical examination and ultrasound findings predict whether a child has appendicitis, how severe it is, and whether they will need surgery? This project tests five models on 782 children from a German hospital and compares them with the clinical scores doctors already use.

It is a rebuilt version of my MSc module project in Machine Learning and Pattern Recognition (Dublin Business School). [What changed](#what-changed-from-the-original) explains each fix.

![Model comparison](figures/auc_by_model.png)

## Key findings

- **Models beat the clinical scores by a wide margin.** The Alvarado and Paediatric Appendicitis Scores alone reach an ROC AUC of about 0.73. Adding lab and ultrasound findings lifts the best models to 0.92 to 0.98.
- **Diagnosis and treatment are the easiest to predict** (best AUC 0.98 and 0.97). The diagnosis score is flattered by how the labels were made, see [Limitations](#limitations).
- **Severity is the hardest.** Only 15% of children had complicated appendicitis. At the default threshold, the class-weighted models catch 61% to 75% of those cases.
- **Simple models hold their own.** Logistic regression is within 0.02 AUC of the best model on every outcome. The neural network is the weakest full model.
- **A leak in the original version.** Length of hospital stay was the strongest input, but it is only known after treatment. It is removed here.

## Results

Stratified 5-fold cross-validation, repeated 3 times. ROC AUC (mean of 15 folds):

| Model | Diagnosis | Severity | Management |
|---|---|---|---|
| Clinical scores only (baseline) | 0.73 | 0.72 | 0.74 |
| Logistic regression | 0.97 | 0.91 | **0.97** |
| Random forest | 0.97 | **0.92** | 0.96 |
| XGBoost | **0.98** | 0.90 | **0.97** |
| Neural network (MLP) | 0.94 | 0.88 | 0.95 |

Share of complicated cases caught (recall) for severity: logistic regression 75%, random forest 68%, XGBoost 61%, neural network 29%. Full results, including balanced accuracy, are in [`figures/results.csv`](figures/results.csv).

<p>
  <img src="figures/confusion_matrices.png" width="100%" alt="XGBoost confusion matrices">
</p>

## What drives the predictions

![Top features](figures/shap_top_features.png)

SHAP values for XGBoost show sensible clinical signals: appendix diameter and visibility on ultrasound for diagnosis, CRP, ileus and abscess for severity, and rebound tenderness and peritonitis for surgery.

## Method

1. **Data.** Regensburg Pediatric Appendicitis dataset from UCI: 782 children, 2016 to 2021, with 52 lab, examination, score and ultrasound inputs.
2. **Outcomes.** Diagnosis (appendicitis or not), severity (complicated or not) and management (surgery or conservative), each modelled separately.
3. **Inputs left out.** Length of stay (known only after treatment), the doctor's suspected diagnosis and an ultrasound image ID.
4. **Preprocessing.** Median filling and scaling for numbers, one-hot encoding for categories with "missing" kept as its own value. Everything sits in scikit-learn pipelines, so it is fitted on training folds only.
5. **Models.** Clinical-score baseline, logistic regression, random forest, XGBoost and a one-layer neural network, with class weights for the imbalanced outcomes.
6. **Evaluation.** Repeated stratified cross-validation with ROC AUC, balanced accuracy and recall, plus out-of-fold ROC curves and confusion matrices.

## What changed from the original

| Original | Revised | Why |
|---|---|---|
| Predicted the first target column, which is treatment, while the report called it diagnosis | All three outcomes modelled and named correctly | The model should answer the question the report describes |
| Treatment had three classes, one with 5 test patients | Surgery vs conservative | The tiny class could not be learned or evaluated |
| Length of stay used as an input | Removed | Not known at admission |
| Cleaning and scaling fitted before the train/test split | Inside pipelines, fitted on training folds | Keeps test data out of training |
| One 80/20 split, accuracy only | Repeated stratified cross-validation, AUC and recall | More reliable, and shows performance on rare cases |
| No baseline | Alvarado and Paediatric Appendicitis Scores | Shows what the models add |
| "CNN" on tabular data with a yes/no output for a 3-class target | Simple neural network | The original set-up could not give valid results |

The original reported 96% accuracy for XGBoost. That figure came from the treatment target with length of stay included, on a single split.

## Limitations

- **Diagnosis labels are partly rule-based.** Children treated without surgery were labelled using their clinical scores and appendix diameter, which are also model inputs. For 99% of these children the label matches that rule.
- **Documentation patterns.** Whether a finding was recorded at all can carry signal, so some feature importance reflects how children were examined.
- **One hospital, 782 children.** Results may not carry over elsewhere.
- **No threshold tuning or external test set.** A hospital would pick a threshold that catches nearly all complicated cases, at the cost of more false alarms.
- **Not a medical tool.** This is a learning project and must not be used for clinical decisions.

## Run it yourself

Requires Python 3.10 or later.

```bash
git clone https://github.com/latedeveloper08/Appendicitis-prediction.git
cd Appendicitis-prediction
pip install -r requirements.txt
jupyter notebook notebooks/appendicitis_classification.ipynb
```

The first run downloads the data from UCI and saves it to `data/appendicitis.csv`.

## Project structure

```
├── data/
│   └── README.md                          source, licence and citation
├── figures/                               charts and results.csv, written by the notebook
├── notebooks/
│   └── appendicitis_classification.ipynb  full analysis
├── src/
│   └── data.py                            loading, outcome coding and input selection
└── requirements.txt
```

## Tools

Python, pandas, scikit-learn, XGBoost, SHAP, Matplotlib, Jupyter

## Data source

Marcinkevičs, R., Reis Wolfertstetter, P., Klimiene, U. et al. (2023). *Regensburg Pediatric Appendicitis Dataset*. Zenodo. [doi:10.5281/zenodo.7669442](https://doi.org/10.5281/zenodo.7669442). Licensed under [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). Also available from the [UCI Machine Learning Repository](https://archive.ics.uci.edu/dataset/938/regensburg+pediatric+appendicitis).

## Author

Bens Binu Samuel · [LinkedIn](https://www.linkedin.com/in/bens-samuel)
